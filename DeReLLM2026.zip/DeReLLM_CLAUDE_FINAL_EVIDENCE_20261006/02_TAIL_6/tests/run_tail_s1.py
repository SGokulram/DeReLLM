#!/usr/bin/env python3

import hashlib
import json
import os
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN_ROOT = ROOT / "frozen"
CORPUS = ROOT / "corpus" / "manifest.jsonl"
RAW = ROOT / "corpus" / "raw"
OUT = ROOT / "runs" / "s1_execution.jsonl"
BASELINE_OUT = ROOT / "runs" / "baseline_execution.jsonl"

ENV_KEYS = {"PATH", "TZ", "LC_ALL", "LANG", "HOME"}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def run_binary(binary: Path, argv, input_path: Path | None):
    binary = str(binary.resolve())
    argv = [str(x) for x in argv]

    with tempfile.TemporaryDirectory(prefix="derellm-tail-run-") as td:
        scratch = Path(td)

        env = {
            k: v
            for k, v in os.environ.items()
            if k in ENV_KEYS
        }

        env.update({
            "PATH": "/usr/bin:/bin",
            "TZ": "UTC",
            "LC_ALL": "C",
            "LANG": "C",
            "HOME": str(scratch),
        })

        stdin_handle = None

        try:
            if input_path is not None:
                stdin_handle = input_path.open("rb")

            cmd = [
                "setarch",
                "x86_64",
                "-R",
                binary,
                *argv,
            ]

            completed = subprocess.run(
                cmd,
                stdin=stdin_handle,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=scratch,
                env=env,
                timeout=5,
                preexec_fn=lambda: os.umask(0o022),
            )

            files_written = {}

            for p in scratch.rglob("*"):
                if p.is_file():
                    rel = str(p.relative_to(scratch))
                    files_written[rel] = digest(p.read_bytes())

            return {
                "stdout_bytes": completed.stdout,
                "stderr_bytes": completed.stderr,
                "exit_status": completed.returncode,
                "files_written": files_written,
                "timeout": False,
            }

        except subprocess.TimeoutExpired as e:
            stdout = e.stdout or b""
            stderr = e.stderr or b""

            return {
                "stdout_bytes": stdout if isinstance(stdout, bytes) else stdout.encode(),
                "stderr_bytes": stderr if isinstance(stderr, bytes) else stderr.encode(),
                "exit_status": None,
                "files_written": {},
                "timeout": True,
            }

        finally:
            if stdin_handle is not None:
                stdin_handle.close()


def make_record(request_id, variant_id, label, expected, rec, capture):
    return {
        "request_id": request_id,
        "variant_id": variant_id,
        "label": label,
        "expected_verdict": expected,
        "input_id": rec["input_id"],
        "argv": rec["argv"],
        "stdout": capture["stdout_bytes"].decode("utf-8", errors="replace"),
        "stderr": capture["stderr_bytes"].decode("utf-8", errors="replace"),
        "stdout_sha256": digest(capture["stdout_bytes"]),
        "stderr_sha256": digest(capture["stderr_bytes"]),
        "exit_status": capture["exit_status"],
        "files_written": capture["files_written"],
        "timeout": capture["timeout"],
    }


def main():
    corpus = [
        json.loads(line)
        for line in CORPUS.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert len(corpus) == 40

    variants = [
        ("req7", "req7_correct", "correct", "accept"),
        ("req7", "req7_famA", "famA", "reject"),
        ("req7", "req7_famB", "famB", "reject"),
        ("req8", "req8_correct", "correct", "accept"),
        ("req8", "req8_famA", "famA", "reject"),
        ("req8", "req8_famB", "famB", "reject"),
    ]

    OUT.parent.mkdir(parents=True, exist_ok=True)

    # Baseline: 40 executions against the original frozen tail.
    baseline = BIN_ROOT / "tail_baseline"

    with BASELINE_OUT.open("w", encoding="utf-8") as f:
        for i, rec in enumerate(corpus, 1):
            input_path = RAW / f"{rec['input_id']}.bin"

            capture = run_binary(
                baseline,
                rec["argv"],
                input_path,
            )

            record = {
                "request_id": "baseline",
                "variant_id": "tail_baseline",
                "label": "baseline",
                "expected_verdict": "baseline",
                "input_id": rec["input_id"],
                "argv": rec["argv"],
                "stdout": capture["stdout_bytes"].decode(
                    "utf-8", errors="replace"
                ),
                "stderr": capture["stderr_bytes"].decode(
                    "utf-8", errors="replace"
                ),
                "stdout_sha256": digest(capture["stdout_bytes"]),
                "stderr_sha256": digest(capture["stderr_bytes"]),
                "exit_status": capture["exit_status"],
                "files_written": capture["files_written"],
                "timeout": capture["timeout"],
            }

            f.write(json.dumps(record, sort_keys=True) + "\n")

            if i % 10 == 0:
                print(f"baseline progress: {i}/40")

    count = 0

    with OUT.open("w", encoding="utf-8") as f:
        for v_index, (req, variant_id, label, expected) in enumerate(
            variants, 1
        ):
            binary = BIN_ROOT / variant_id

            print(f"\n[{v_index}/6] {variant_id}")

            for rec in corpus:
                input_path = RAW / f"{rec['input_id']}.bin"

                capture = run_binary(
                    binary,
                    rec["argv"],
                    input_path,
                )

                record = make_record(
                    req,
                    variant_id,
                    label,
                    expected,
                    rec,
                    capture,
                )

                f.write(json.dumps(record, sort_keys=True) + "\n")
                f.flush()

                count += 1

                if count % 20 == 0:
                    print(f"progress: {count}/240")

    print()
    print("Baseline executions: 40")
    print(f"S1 executions: {count}")

    assert count == 240


if __name__ == "__main__":
    main()
