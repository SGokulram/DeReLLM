#!/usr/bin/env python3

from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "corpus" / "raw"
MANIFEST = ROOT / "corpus" / "manifest.jsonl"

RAW.mkdir(parents=True, exist_ok=True)

cases = [
    ("empty", b"", []),
    ("one_line", b"one\n", []),
    ("five_lines", b"1\n2\n3\n4\n5\n", []),
    ("ten_lines", b"1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n", []),
    ("eleven_lines", b"1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n", []),
    ("twenty_lines", b"".join(f"{i}\n".encode() for i in range(1, 21)), []),
    ("twentyfive_lines", b"".join(f"{i}\n".encode() for i in range(1, 26)), []),
    ("fifty_lines", b"".join(f"{i}\n".encode() for i in range(1, 51)), []),
    ("no_final_newline", b"1\n2\n3\n4\n5", []),
    ("blank_lines", b"a\n\nb\n\nc\n", []),

    ("long_lines", b"alpha" * 1000 + b"\n" + b"beta" * 1000 + b"\n", []),
    ("spaces", b"  a  \n  b  \n  c  \n", []),
    ("tabs", b"a\tb\nc\td\n", []),
    ("crlf", b"a\r\nb\r\nc\r\n", []),
    ("embedded_nul", b"a\x00b\nc\x00d\n", []),
    ("utf8", "தமிழ்\nhello\n世界\n".encode("utf-8"), []),
    ("mixed_lengths", b"a\nbb\nccc\ndddd\neeeee\n", []),
    ("many_short", b"\n".join([b"x"] * 30) + b"\n", []),
    ("one_long_no_newline", b"z" * 4096, []),

    ("n_zero", b"".join(f"{i}\n".encode() for i in range(1, 26)), ["-n", "0"]),
    ("n_one", b"".join(f"{i}\n".encode() for i in range(1, 26)), ["-n", "1"]),
    ("n_two", b"".join(f"{i}\n".encode() for i in range(1, 26)), ["-n", "2"]),
    ("n_five", b"".join(f"{i}\n".encode() for i in range(1, 26)), ["-n", "5"]),
    ("n_nine", b"".join(f"{i}\n".encode() for i in range(1, 26)), ["-n", "9"]),
    ("n_ten", b"".join(f"{i}\n".encode() for i in range(1, 26)), ["-n", "10"]),
    ("n_eleven", b"".join(f"{i}\n".encode() for i in range(1, 26)), ["-n", "11"]),
    ("n_twenty", b"".join(f"{i}\n".encode() for i in range(1, 26)), ["-n", "20"]),
    ("n_large", b"".join(f"{i}\n".encode() for i in range(1, 26)), ["-n", "999999"]),

    ("c_zero", b"abcdefghij", ["-c", "0"]),
    ("c_one", b"abcdefghij", ["-c", "1"]),
    ("c_five", b"abcdefghij", ["-c", "5"]),
    ("c_ten", b"abcdefghij", ["-c", "10"]),
    ("c_large", b"abcdefghij", ["-c", "999999"]),
    ("c_plus", b"abcdefghij", ["-c", "+3"]),
    ("n_plus", b"1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n", ["-n", "+3"]),
    ("n_minus", b"1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n", ["-n", "-3"]),
    ("zero_terminated", b"a\0b\0c\0d\0", ["-z", "-n", "2"]),
    ("multi_options", b"".join(f"{i}\n".encode() for i in range(1, 31)), ["-q", "-n", "7"]),
    ("file_header_mode", b"".join(f"{i}\n".encode() for i in range(1, 16)), ["-v", "-n", "4"]),
    ("large_default", b"".join(f"{i:04d}\n".encode() for i in range(1, 101)), []),
]

assert len(cases) == 40, len(cases)

MANIFEST.unlink(missing_ok=True)

with MANIFEST.open("w", encoding="utf-8") as f:
    for input_id, data, argv in cases:
        path = RAW / f"{input_id}.bin"
        path.write_bytes(data)

        f.write(json.dumps({
            "input_id": input_id,
            "binary": "tail",
            "file": f"corpus/raw/{input_id}.bin",
            "argv": argv,
        }, sort_keys=True) + "\n")

print(f"Tail deterministic inputs: {len(cases)}")
print(f"Manifest: {MANIFEST}")
