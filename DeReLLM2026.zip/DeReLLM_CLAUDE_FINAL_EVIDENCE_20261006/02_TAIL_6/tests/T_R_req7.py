#!/usr/bin/env python3

import subprocess
import sys
import tempfile
from pathlib import Path


def run(cmd, data=None):
    return subprocess.run(
        cmd,
        input=data,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cmd[0].parent if isinstance(cmd[0], Path) else None,
        timeout=5,
    )


def main():
    if len(sys.argv) != 2:
        raise SystemExit(f"usage: {sys.argv[0]} BINARY")

    binary = Path(sys.argv[1]).resolve()

    lines = [f"line-{i}\n" for i in range(1, 26)]
    data = "".join(lines).encode()

    expected_default = "".join(lines[5:]).encode()   # 6..25
    expected_n10 = "".join(lines[15:]).encode()      # 16..25

    with tempfile.TemporaryDirectory(prefix="derellm-tr-req7-") as td:
        p = Path(td) / "input.txt"
        p.write_bytes(data)

        base_cmd = [str(binary)]

        r_default = subprocess.run(
            base_cmd,
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5,
        )

        r_explicit = subprocess.run(
            [str(binary), "-n", "10"],
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=5,
        )

        ok = True
        reasons = []

        if r_default.returncode != 0:
            ok = False
            reasons.append(f"default exit={r_default.returncode}")

        if r_explicit.returncode != 0:
            ok = False
            reasons.append(f"explicit exit={r_explicit.returncode}")

        if r_default.stderr:
            ok = False
            reasons.append("default stderr not empty")

        if r_explicit.stderr:
            ok = False
            reasons.append("explicit -n stderr not empty")

        if r_default.stdout != expected_default:
            ok = False
            reasons.append(
                f"default output mismatch: got {len(r_default.stdout)} bytes"
            )

        if r_explicit.stdout != expected_n10:
            ok = False
            reasons.append(
                f"explicit -n 10 output mismatch: got {len(r_explicit.stdout)} bytes"
            )

        print(f"binary: {binary}")
        print(f"default_20_behavior: {'PASS' if r_default.stdout == expected_default else 'FAIL'}")
        print(f"explicit_n10_behavior: {'PASS' if r_explicit.stdout == expected_n10 else 'FAIL'}")
        print(f"stderr_clean: {'PASS' if not r_default.stderr and not r_explicit.stderr else 'FAIL'}")
        print(f"exit_clean: {'PASS' if r_default.returncode == 0 and r_explicit.returncode == 0 else 'FAIL'}")

        if ok:
            print("T_R_REQ7: PASS")
            return 0

        print("T_R_REQ7: FAIL")
        for reason in reasons:
            print(f"  reason: {reason}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
