#!/usr/bin/env python3

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

BASELINE_FILE = ROOT / "runs" / "baseline_execution.jsonl"
S1_FILE = ROOT / "runs" / "s1_execution.jsonl"
TR_FILE = ROOT / "results" / "T_R_results.txt"

OUT_DIR = ROOT / "runs" / "s4_verdicts"
OUT_FILE = OUT_DIR / "final.jsonl"
SUMMARY_FILE = ROOT / "results" / "S4_summary.json"


def load_jsonl(path):
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def tr_results():
    text = TR_FILE.read_text(encoding="utf-8")

    expected = {
        ("req7", "req7_correct"): True,
        ("req7", "req7_famA"): False,
        ("req7", "req7_famB"): False,
        ("req8", "req8_correct"): True,
        ("req8", "req8_famA"): False,
        ("req8", "req8_famB"): False,
    }

    actual = {}

    for line in text.splitlines():
        line = line.strip()

        if not line or ":" not in line:
            continue

        left, right = line.split(":", 1)

        if not left.startswith("Req"):
            continue

        parts = left.split()

        req_num = parts[0][3:]
        variant_word = parts[1]

        req = f"req{req_num}"

        if variant_word == "correct":
            variant = f"{req}_correct"
        elif variant_word == "Family":
            variant = f"{req}_fam{parts[2][-1]}"
        else:
            continue

        actual[(req, variant)] = right.strip() == "PASS"

    if actual != expected:
        raise SystemExit(
            "T_R result mismatch.\n"
            f"Expected: {expected}\n"
            f"Actual:   {actual}"
        )

    return actual


def same_files(a, b):
    return a == b


def evaluate_req7(base, variant):
    unexplained = []

    # Authorized change:
    # default line count changes from 10 to 20.
    # Therefore stdout may change ONLY when the invocation omits -n/--lines.
    argv = variant["argv"]

    explicit_line_count = (
        "-n" in argv or "--lines" in argv
        or any(
            str(x).startswith("--lines=")
            for x in argv
        )
    )

    stdout_same = (
        variant["stdout_sha256"] == base["stdout_sha256"]
    )

    stderr_same = (
        variant["stderr_sha256"] == base["stderr_sha256"]
    )

    exit_same = (
        variant["exit_status"] == base["exit_status"]
    )

    files_same = same_files(
        variant["files_written"],
        base["files_written"],
    )

    if explicit_line_count and not stdout_same:
        unexplained.append("stdout changed under explicit -n/--lines")

    if not stderr_same:
        unexplained.append("stderr changed")

    if not exit_same:
        unexplained.append("exit status changed")

    if not files_same:
        unexplained.append("files_written changed")

    # For default invocations, stdout change is authorized.
    # For explicit line-count invocations, stdout must remain identical.
    return {
        "explained_deltas": (
            ["stdout changed under authorized default line-count behavior"]
            if not stdout_same and not explicit_line_count
            else []
        ),
        "unexplained_deltas": unexplained,
    }


def evaluate_req8(base, variant):
    unexplained = []

    # The deterministic corpus intentionally contains no -f/--follow
    # invocation, because follow mode is exercised by T_R_req8.py.
    #
    # Therefore every S1 observation for Req8 must remain identical
    # to baseline. Any observed S1 delta is collateral behavior.

    if variant["stdout_sha256"] != base["stdout_sha256"]:
        unexplained.append("stdout changed")

    if variant["stderr_sha256"] != base["stderr_sha256"]:
        unexplained.append("stderr changed")

    if variant["exit_status"] != base["exit_status"]:
        unexplained.append("exit status changed")

    if variant["files_written"] != base["files_written"]:
        unexplained.append("files_written changed")

    return {
        "explained_deltas": [],
        "unexplained_deltas": unexplained,
    }


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    SUMMARY_FILE.parent.mkdir(parents=True, exist_ok=True)

    baseline_rows = load_jsonl(BASELINE_FILE)
    variant_rows = load_jsonl(S1_FILE)

    if len(baseline_rows) != 40:
        raise SystemExit(
            f"Expected 40 baseline records, got {len(baseline_rows)}"
        )

    if len(variant_rows) != 240:
        raise SystemExit(
            f"Expected 240 S1 records, got {len(variant_rows)}"
        )

    tr = tr_results()

    baseline = {
        r["input_id"]: r
        for r in baseline_rows
    }

    variants = {}

    for r in variant_rows:
        key = r["variant_id"]
        variants.setdefault(key, []).append(r)

    expected_variants = {
        "req7_correct": ("req7", "correct"),
        "req7_famA": ("req7", "famA"),
        "req7_famB": ("req7", "famB"),
        "req8_correct": ("req8", "correct"),
        "req8_famA": ("req8", "famA"),
        "req8_famB": ("req8", "famB"),
    }

    if set(variants) != set(expected_variants):
        raise SystemExit(
            f"Variant mismatch: {sorted(variants)}"
        )

    results = []

    for variant_id, (req, label) in expected_variants.items():
        rows = variants[variant_id]

        if len(rows) != 40:
            raise SystemExit(
                f"{variant_id}: expected 40 rows, got {len(rows)}"
            )

        explained = []
        unexplained = []

        for row in rows:
            input_id = row["input_id"]

            if input_id not in baseline:
                raise SystemExit(
                    f"{variant_id}: missing baseline input {input_id}"
                )

            base = baseline[input_id]

            if req == "req7":
                evaluation = evaluate_req7(base, row)
            elif req == "req8":
                evaluation = evaluate_req8(base, row)
            else:
                raise SystemExit(f"Unknown request: {req}")

            if evaluation["explained_deltas"]:
                explained.append({
                    "input_id": input_id,
                    "deltas": evaluation["explained_deltas"],
                })

            if evaluation["unexplained_deltas"]:
                unexplained.append({
                    "input_id": input_id,
                    "deltas": evaluation["unexplained_deltas"],
                })

        intent_pass = tr[(req, variant_id)]

        final_verdict = (
            "accept"
            if intent_pass and not unexplained
            else "reject"
        )

        results.append({
            "request_id": req,
            "variant_id": variant_id,
            "label": label,
            "intent_test": "PASS" if intent_pass else "FAIL",
            "explained_delta_count": len(explained),
            "unexplained_delta_count": len(unexplained),
            "explained_deltas": explained,
            "unexplained_deltas": unexplained,
            "final_verdict": final_verdict,
        })

    with OUT_FILE.open("w", encoding="utf-8") as f:
        for result in results:
            f.write(
                json.dumps(
                    result,
                    sort_keys=True,
                )
                + "\n"
            )

    tp = tn = fp = fn = 0

    gold = {
        "req7_correct": "accept",
        "req7_famA": "reject",
        "req7_famB": "reject",
        "req8_correct": "accept",
        "req8_famA": "reject",
        "req8_famB": "reject",
    }

    for r in results:
        predicted = r["final_verdict"]
        expected = gold[r["variant_id"]]

        if predicted == "accept" and expected == "accept":
            tp += 1
        elif predicted == "reject" and expected == "reject":
            tn += 1
        elif predicted == "accept" and expected == "reject":
            fp += 1
        elif predicted == "reject" and expected == "accept":
            fn += 1

    total = len(results)

    accuracy = (tp + tn) / total if total else 0.0
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = (
        2 * precision * recall / (precision + recall)
        if (precision + recall)
        else 0.0
    )

    summary = {
        "benchmark": "tail_third_binary",
        "variants": total,
        "gold_accept": 2,
        "gold_reject": 4,
        "TP": tp,
        "TN": tn,
        "FP": fp,
        "FN": fn,
        "accuracy": accuracy,
        "precision": precision,
        "recall": recall,
        "F1": f1,
        "all_match_gold": all(
            r["final_verdict"] == gold[r["variant_id"]]
            for r in results
        ),
        "input_count": 40,
        "baseline_executions": 40,
        "variant_executions": 240,
        "total_s1_executions": 280,
        "T_R_SHA256": sha256_bytes(
            TR_FILE.read_bytes()
        ),
        "S1_SHA256": sha256_bytes(
            S1_FILE.read_bytes()
        ),
        "baseline_SHA256": sha256_bytes(
            BASELINE_FILE.read_bytes()
        ),
    }

    SUMMARY_FILE.write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    print("=== TAIL S4 RESULTS ===")

    for r in results:
        print(
            f"{r['variant_id']:15s} "
            f"intent={r['intent_test']:4s} "
            f"explained={r['explained_delta_count']:3d} "
            f"unexplained={r['unexplained_delta_count']:3d} "
            f"=> {r['final_verdict']}"
        )

    print()
    print("=== METRICS ===")
    print(f"TP={tp} TN={tn} FP={fp} FN={fn}")
    print(f"accuracy={accuracy:.6f}")
    print(f"precision={precision:.6f}")
    print(f"recall={recall:.6f}")
    print(f"F1={f1:.6f}")
    print(f"all_match_gold={summary['all_match_gold']}")


if __name__ == "__main__":
    main()
