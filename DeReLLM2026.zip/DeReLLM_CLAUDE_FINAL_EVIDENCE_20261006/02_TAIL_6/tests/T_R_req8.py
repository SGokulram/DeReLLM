#!/usr/bin/env python3

import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path


def reader(pipe, chunks):
    try:
        while True:
            data = pipe.readline()
            if not data:
                break
            chunks.append(data)
    except Exception:
        pass


def main():
    if len(sys.argv) != 2:
        raise SystemExit(f"usage: {sys.argv[0]} BINARY")

    binary = Path(sys.argv[1]).resolve()

    with tempfile.TemporaryDirectory(prefix="derellm-tr-req8-") as td:
        root = Path(td)
        target = root / "follow.txt"

        target.write_text("initial\n", encoding="utf-8")

        cmd = [
            str(binary),
            "--retry",
            "-s", "0.1",
            "--max-unchanged-stats=1",
            "-f",
            str(target),
        ]

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )

        stdout_chunks = []
        stderr_chunks = []

        stdout_thread = threading.Thread(
            target=reader,
            args=(proc.stdout, stdout_chunks),
            daemon=True,
        )
        stderr_thread = threading.Thread(
            target=reader,
            args=(proc.stderr, stderr_chunks),
            daemon=True,
        )

        stdout_thread.start()
        stderr_thread.start()

        try:
            # Give tail time to open the original pathname.
            time.sleep(0.6)

            with target.open("a", encoding="utf-8") as f:
                f.write("first\n")
                f.flush()

            # Give tail time to observe the append.
            time.sleep(0.6)

            replacement = root / "replacement.tmp"
            replacement.write_text(
                "replacement\n",
                encoding="utf-8",
            )

            # Atomic pathname replacement.
            replacement.replace(target)

            deadline = time.monotonic() + 6.0
            found_replacement = False

            while time.monotonic() < deadline:
                observed = "".join(stdout_chunks)

                if "replacement" in observed:
                    found_replacement = True
                    break

                time.sleep(0.1)

            observed_stdout = "".join(stdout_chunks)
            observed_stderr = "".join(stderr_chunks)

            unauthorized_stderr = (
                "explicit follow option used" in observed_stderr
            )

            print(f"binary: {binary}")
            print(
                "replacement_followed: "
                f"{'PASS' if found_replacement else 'FAIL'}"
            )
            print(
                "unauthorized_stderr: "
                f"{'FAIL' if unauthorized_stderr else 'PASS'}"
            )

            print(
                "stdout_contains_replacement: "
                f"{'YES' if 'replacement' in observed_stdout else 'NO'}"
            )

            if observed_stderr:
                print("stderr:")
                print(observed_stderr, end="")

            if found_replacement and not unauthorized_stderr:
                print("T_R_REQ8: PASS")
                return 0

            print("T_R_REQ8: FAIL")
            return 1

        finally:
            if proc.poll() is None:
                proc.terminate()

                try:
                    proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()

            stdout_thread.join(timeout=1)
            stderr_thread.join(timeout=1)


if __name__ == "__main__":
    raise SystemExit(main())
