#!/usr/bin/env python3

import csv
import json
import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

ROOT = Path.home() / "derellm"
OUT = ROOT / "runtime_experiment" / "raw"

GHIDRA = ROOT / "tools/ghidra_11.4.2_PUBLIC/support/analyzeHeadless"
S3_SCRIPT = ROOT / "v6_experiment/scripts/s3_ghidra/V6StaticEvidence.java"

TR_REQ7 = ROOT / "third_binary_plan/tests/T_R_req7.py"
TR_REQ8 = ROOT / "third_binary_plan/tests/T_R_req8.py"

TAIL_BINARIES = ROOT / "third_binary_plan/frozen"

PHASE7 = ROOT / "runs/phase7_inputs.jsonl"
RAG_SCRIPT = ROOT / "runs/phase8_rag_index.py"


def now():
    return time.monotonic_ns()


def run_command(cmd, cwd=None, env=None, timeout=None):
    start = now()

    try:
        p = subprocess.run(
            cmd,
            cwd=cwd,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
        )

        end = now()

        return {
            "returncode": p.returncode,
            "elapsed_seconds": (end - start) / 1e9,
            "timeout": False,
            "stdout_sha256": __import__("hashlib").sha256(
                p.stdout
            ).hexdigest(),
            "stderr_sha256": __import__("hashlib").sha256(
                p.stderr
            ).hexdigest(),
        }

    except subprocess.TimeoutExpired as e:
        end = now()

        return {
            "returncode": None,
            "elapsed_seconds": (end - start) / 1e9,
            "timeout": True,
            "stdout_sha256": __import__("hashlib").sha256(
                e.stdout or b""
            ).hexdigest(),
            "stderr_sha256": __import__("hashlib").sha256(
                e.stderr or b""
            ).hexdigest(),
        }


def base_env():
    env = {
        "PATH": "/usr/bin:/bin",
        "TZ": "UTC",
        "LC_ALL": "C",
        "LANG": "C",
    }

    env["HOME"] = os.environ.get("HOME", "/tmp")

    return env


def write_timing_csv(rows):
    path = OUT / "stage_timing_runs.csv"

    fields = [
        "stage",
        "run_id",
        "target",
        "elapsed_seconds",
        "returncode",
        "timeout",
        "stdout_sha256",
        "stderr_sha256",
    ]

    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    return path


def time_rag(run_id):
    with tempfile.TemporaryDirectory(
        prefix="derellm-runtime-rag-"
    ) as td:
        work = Path(td)
        (work / "runs").mkdir()

        shutil.copy2(
            PHASE7,
            work / "runs/phase7_inputs.jsonl",
        )

        shutil.copy2(
            RAG_SCRIPT,
            work / "phase8_rag_index.py",
        )

        result = run_command(
            ["python3", "phase8_rag_index.py"],
            cwd=work,
            env=base_env(),
            timeout=300,
        )

        return {
            "stage": "rag_index",
            "run_id": run_id,
            "target": "20_phase7_inputs",
            **result,
        }


def time_s4_tail(run_id):
    script = ROOT / "third_binary_plan/tests/run_tail_s4.py"

    # Work on a copy so the frozen third-binary S4 output is untouched.
    with tempfile.TemporaryDirectory(
        prefix="derellm-runtime-s4-tail-"
    ) as td:
        work = Path(td)

        # This stage is timed from the existing frozen S4 input artifacts
        # through the deterministic tail evaluator.
        shutil.copytree(
            ROOT / "third_binary_plan",
            work / "third_binary_plan",
            dirs_exist_ok=True,
        )

        result = run_command(
            [
                "python3",
                str(
                    work
                    / "third_binary_plan/tests/run_tail_s4.py"
                ),
            ],
            cwd=work,
            env=base_env(),
            timeout=300,
        )

        return {
            "stage": "s4_tail",
            "run_id": run_id,
            "target": "6_tail_variants",
            **result,
        }


def time_tr_req7(run_id):
    rows = []

    for variant in [
        "req7_correct",
        "req7_famA",
        "req7_famB",
    ]:
        result = run_command(
            [
                "python3",
                str(TR_REQ7),
                str(TAIL_BINARIES / variant),
            ],
            env=base_env(),
            timeout=30,
        )

        rows.append({
            "stage": "intent_req7",
            "run_id": run_id,
            "target": variant,
            **result,
        })

    return rows


def time_tr_req8(run_id):
    rows = []

    for variant in [
        "req8_correct",
        "req8_famA",
        "req8_famB",
    ]:
        result = run_command(
            [
                "python3",
                str(TR_REQ8),
                str(TAIL_BINARIES / variant),
            ],
            env=base_env(),
            timeout=20,
        )

        rows.append({
            "stage": "intent_req8",
            "run_id": run_id,
            "target": variant,
            **result,
        })

    return rows


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    rows = []

    # Three repeated measurements where stage reruns are independent
    # and practical.
    for run_id in range(1, 4):
        print(f"=== RUNTIME REPETITION {run_id}/3 ===")

        rag = time_rag(run_id)
        rows.append(rag)
        print(
            f"RAG index: {rag['elapsed_seconds']:.3f}s"
        )

        tail_s4 = time_s4_tail(run_id)
        rows.append(tail_s4)
        print(
            f"Tail S4: {tail_s4['elapsed_seconds']:.3f}s"
        )

        rows.extend(time_tr_req7(run_id))
        rows.extend(time_tr_req8(run_id))

        print("Intent tests complete.")

    path = write_timing_csv(rows)

    print()
    print("Timing records:", len(rows))
    print("Output:", path)


if __name__ == "__main__":
    main()
