#!/usr/bin/env python3

import csv
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import tempfile
import time
from pathlib import Path

ROOT = Path.home() / "derellm"
RUNTIME = ROOT / "runtime_experiment"
RAW = RUNTIME / "raw"
RESULTS = RUNTIME / "results"
LOGS = RUNTIME / "logs"

GHIDRA = ROOT / "tools/ghidra_11.4.2_PUBLIC/support/analyzeHeadless"

S3_RUNNER = ROOT / "v6_experiment/scripts/run_s3.sh"
S3_SCRIPT_DIR = ROOT / "v6_experiment/scripts/s3_ghidra"

S1_ORIGINAL = ROOT / "v6_experiment/scripts/run_s1.py"
S1_TAIL = ROOT / "third_binary_plan/tests/run_tail_s1.py"

S4_ORIGINAL = ROOT / "v6_experiment/scripts/run_s4_semantic_v4.py"
S4_TAIL = ROOT / "third_binary_plan/tests/run_tail_s4.py"

RAG_SCRIPT = ROOT / "runs/phase8_rag_index.py"
PHASE7 = ROOT / "runs/phase7_inputs.jsonl"

DET_SCREEN = ROOT / "v6_experiment/scripts/screen.py"

PROTOCOL = RUNTIME / "RUNTIME_PROTOCOL_FROZEN.txt"


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def monotonic():
    return time.monotonic_ns()


def controlled_env():
    env = {
        "PATH": "/usr/bin:/bin",
        "TZ": "UTC",
        "LC_ALL": "C",
        "LANG": "C",
        "HOME": os.environ.get("HOME", "/tmp"),
    }
    return env


def run(cmd, cwd=None, timeout=None):
    start = monotonic()

    try:
        p = subprocess.run(
            cmd,
            cwd=cwd,
            env=controlled_env(),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
        )

        end = monotonic()

        return {
            "elapsed_seconds": (end - start) / 1e9,
            "returncode": p.returncode,
            "timeout": False,
            "stdout_sha256": hashlib.sha256(p.stdout).hexdigest(),
            "stderr_sha256": hashlib.sha256(p.stderr).hexdigest(),
        }

    except subprocess.TimeoutExpired as e:
        end = monotonic()

        out = e.stdout or b""
        err = e.stderr or b""

        if isinstance(out, str):
            out = out.encode()
        if isinstance(err, str):
            err = err.encode()

        return {
            "elapsed_seconds": (end - start) / 1e9,
            "returncode": None,
            "timeout": True,
            "stdout_sha256": hashlib.sha256(out).hexdigest(),
            "stderr_sha256": hashlib.sha256(err).hexdigest(),
        }


def record(rows, stage, target, run_id, result):
    rows.append({
        "stage": stage,
        "target": target,
        "run_id": run_id,
        **result,
    })


def time_ghidra(run_id):
    """
    Time Ghidra over all 18 existing head/cut variants plus 6 tail variants.
    Work is isolated into a temporary Ghidra project/output directory.
    Frozen artifacts are never overwritten.
    """

    with tempfile.TemporaryDirectory(prefix="derellm-runtime-ghidra-") as td:
        work = Path(td)
        project_root = work / "projects"
        out_root = work / "static"
        project_root.mkdir()
        out_root.mkdir()

        # Original 18 variants.
        for req in range(1, 7):
            for variant in ("correct", "famA", "famB"):
                if req <= 3:
                    binary = ROOT / "v6_variants/bin" / f"req{req}" / f"head_{variant}"
                else:
                    binary = ROOT / "v6_variants/bin" / f"req{req}" / f"cut_{variant}"

                req_out = out_root / f"req{req}"
                req_out.mkdir(exist_ok=True)
                project = f"runtime_v6_req{req}_{binary.name}"

                result = run(
                    [
                        str(GHIDRA),
                        str(project_root),
                        project,
                        "-import",
                        str(binary),
                        "-overwrite",
                        "-scriptPath",
                        str(S3_SCRIPT_DIR),
                        "-postscript",
                        "V6StaticEvidence.java",
                        str(req_out),
                    ],
                    timeout=600,
                )

                if result["timeout"] or result["returncode"] != 0:
                    return {
                        "stage": "ghidra",
                        "target": "24_variants",
                        "run_id": run_id,
                        "elapsed_seconds": result["elapsed_seconds"],
                        "returncode": result["returncode"],
                        "timeout": result["timeout"],
                        "stdout_sha256": result["stdout_sha256"],
                        "stderr_sha256": result["stderr_sha256"],
                        "status": "FAIL",
                    }

        # Six tail variants use the same Ghidra postscript.
        tail_out = out_root / "tail"
        tail_out.mkdir()

        tail_variants = [
            "req7_correct", "req7_famA", "req7_famB",
            "req8_correct", "req8_famA", "req8_famB",
        ]

        for variant in tail_variants:
            binary = ROOT / "third_binary_plan/frozen" / variant
            project = f"runtime_tail_{variant}"

            result = run(
                [
                    str(GHIDRA),
                    str(project_root),
                    project,
                    "-import",
                    str(binary),
                    "-overwrite",
                    "-scriptPath",
                    str(S3_SCRIPT_DIR),
                    "-postscript",
                    "V6StaticEvidence.java",
                    str(tail_out),
                ],
                timeout=600,
            )

            if result["timeout"] or result["returncode"] != 0:
                return {
                    "stage": "ghidra",
                    "target": "24_variants",
                    "run_id": run_id,
                    "elapsed_seconds": result["elapsed_seconds"],
                    "returncode": result["returncode"],
                    "timeout": result["timeout"],
                    "stdout_sha256": result["stdout_sha256"],
                    "stderr_sha256": result["stderr_sha256"],
                    "status": "FAIL",
                }

        return {
            "stage": "ghidra",
            "target": "24_variants",
            "run_id": run_id,
            "elapsed_seconds": None,
            "returncode": 0,
            "timeout": False,
            "stdout_sha256": sha256_file(PROTOCOL)
                if PROTOCOL.exists() else "",
            "stderr_sha256": "",
            "status": "PASS",
        }


def time_rag(run_id):
    with tempfile.TemporaryDirectory(prefix="derellm-runtime-rag-") as td:
        work = Path(td)
        (work / "runs").mkdir()

        shutil.copy2(PHASE7, work / "runs/phase7_inputs.jsonl")
        shutil.copy2(RAG_SCRIPT, work / "phase8_rag_index.py")

        result = run(
            ["python3", "phase8_rag_index.py"],
            cwd=work,
            timeout=300,
        )

        return {
            "stage": "rag_index",
            "target": "20_phase7_inputs",
            "run_id": run_id,
            **result,
            "status": "PASS" if result["returncode"] == 0 and not result["timeout"] else "FAIL",
        }


def time_s1_original(run_id):
    with tempfile.TemporaryDirectory(prefix="derellm-runtime-s1-original-") as td:
        work = Path(td)

        # Copy the complete v6 experiment so all relative resources resolve.
        shutil.copytree(
            ROOT / "v6_experiment",
            work / "v6_experiment",
            dirs_exist_ok=True,
        )
        shutil.copytree(
            ROOT / "v6_variants",
            work / "v6_variants",
            dirs_exist_ok=True,
        )

        script = work / "v6_experiment/scripts/run_s1.py"

        result = run(
            ["python3", str(script)],
            cwd=work,
            timeout=1800,
        )

        return {
            "stage": "s1",
            "target": "18_original_variants_720_exec",
            "run_id": run_id,
            **result,
            "status": "PASS" if result["returncode"] == 0 and not result["timeout"] else "FAIL",
        }


def time_s1_tail(run_id):
    with tempfile.TemporaryDirectory(prefix="derellm-runtime-s1-tail-") as td:
        work = Path(td)

        shutil.copytree(
            ROOT / "third_binary_plan",
            work / "third_binary_plan",
            dirs_exist_ok=True,
        )

        script = work / "third_binary_plan/tests/run_tail_s1.py"

        result = run(
            ["python3", str(script)],
            cwd=work,
            timeout=900,
        )

        return {
            "stage": "s1",
            "target": "6_tail_variants_240_exec",
            "run_id": run_id,
            **result,
            "status": "PASS" if result["returncode"] == 0 and not result["timeout"] else "FAIL",
        }


def time_s4_original(run_id):
    with tempfile.TemporaryDirectory(prefix="derellm-runtime-s4-original-") as td:
        work = Path(td)

        shutil.copytree(
            ROOT / "v6_experiment",
            work / "v6_experiment",
            dirs_exist_ok=True,
        )
        shutil.copytree(
            ROOT / "v6_variants",
            work / "v6_variants",
            dirs_exist_ok=True,
        )

        script = work / "v6_experiment/scripts/run_s4_semantic_v4.py"

        result = run(
            ["python3", str(script)],
            cwd=work,
            timeout=900,
        )

        return {
            "stage": "s4",
            "target": "18_original_variants",
            "run_id": run_id,
            **result,
            "status": "PASS" if result["returncode"] == 0 and not result["timeout"] else "FAIL",
        }


def time_s4_tail(run_id):
    with tempfile.TemporaryDirectory(prefix="derellm-runtime-s4-tail-") as td:
        work = Path(td)

        shutil.copytree(
            ROOT / "third_binary_plan",
            work / "third_binary_plan",
            dirs_exist_ok=True,
        )

        script = work / "third_binary_plan/tests/run_tail_s4.py"

        result = run(
            ["python3", str(script)],
            cwd=work,
            timeout=600,
        )

        return {
            "stage": "s4",
            "target": "6_tail_variants",
            "run_id": run_id,
            **result,
            "status": "PASS" if result["returncode"] == 0 and not result["timeout"] else "FAIL",
        }


def time_determinism(run_id):
    """
    Isolated copy of the existing frozen determinism screening.
    We deliberately do not execute it in its original location.
    """

    with tempfile.TemporaryDirectory(prefix="derellm-runtime-det-") as td:
        work = Path(td)

        shutil.copytree(
            ROOT / "v6_experiment",
            work / "v6_experiment",
            dirs_exist_ok=True,
        )
        shutil.copytree(
            ROOT / "v6_variants",
            work / "v6_variants",
            dirs_exist_ok=True,
        )

        script = work / "v6_experiment/scripts/screen.py"

        result = run(
            ["python3", str(script)],
            cwd=work,
            timeout=1800,
        )

        return {
            "stage": "determinism",
            "target": "80_inputs_x5_400_exec",
            "run_id": run_id,
            **result,
            "status": "PASS" if result["returncode"] == 0 and not result["timeout"] else "FAIL",
        }


def write_csv(rows):
    path = RESULTS / "runtime.csv"
    fields = [
        "stage",
        "target",
        "run_id",
        "elapsed_seconds",
        "returncode",
        "timeout",
        "status",
        "stdout_sha256",
        "stderr_sha256",
    ]

    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    return path


def summarize(rows):
    summary = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "protocol_sha256": sha256_file(PROTOCOL) if PROTOCOL.exists() else None,
        "stages": {},
    }

    for stage in sorted(set(r["stage"] for r in rows)):
        vals = [
            r["elapsed_seconds"]
            for r in rows
            if r["stage"] == stage and r["elapsed_seconds"] is not None
        ]

        summary["stages"][stage] = {
            "n_measurements": len(vals),
            "mean_seconds": statistics.mean(vals) if vals else None,
            "median_seconds": statistics.median(vals) if vals else None,
            "min_seconds": min(vals) if vals else None,
            "max_seconds": max(vals) if vals else None,
            "all_status_pass": all(
                r.get("status") == "PASS"
                for r in rows
                if r["stage"] == stage
            ),
        }

    return summary


def main():
    RAW.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)

    rows = []
    log_path = LOGS / "runtime_run.log"

    with log_path.open("w", encoding="utf-8") as log:
        for rep in range(1, 4):
            rep_start = monotonic()

            msg = f"\n=== RUNTIME REPETITION {rep}/3 ===\n"
            print(msg, end="")
            log.write(msg)

            # Ghidra
            print("Ghidra...")
            start = monotonic()
            gh = time_ghidra(rep)
            gh_elapsed = (monotonic() - start) / 1e9
            gh["elapsed_seconds"] = gh_elapsed

            rows.append(gh)

            print(f"Ghidra: {gh_elapsed:.3f}s [{gh['status']}]")
            log.write(f"Ghidra: {gh_elapsed:.3f}s [{gh['status']}]\n")

            # RAG
            rag = time_rag(rep)
            rows.append(rag)
            print(f"RAG: {rag['elapsed_seconds']:.3f}s [{rag['status']}]")
            log.write(f"RAG: {rag['elapsed_seconds']:.3f}s [{rag['status']}]\n")

            # S1 original
            s1o = time_s1_original(rep)
            rows.append(s1o)
            print(f"S1 original: {s1o['elapsed_seconds']:.3f}s [{s1o['status']}]")
            log.write(
                f"S1 original: {s1o['elapsed_seconds']:.3f}s [{s1o['status']}]\n"
            )

            # S1 tail
            s1t = time_s1_tail(rep)
            rows.append(s1t)
            print(f"S1 tail: {s1t['elapsed_seconds']:.3f}s [{s1t['status']}]")
            log.write(
                f"S1 tail: {s1t['elapsed_seconds']:.3f}s [{s1t['status']}]\n"
            )

            # S4 original
            s4o = time_s4_original(rep)
            rows.append(s4o)
            print(f"S4 original: {s4o['elapsed_seconds']:.3f}s [{s4o['status']}]")
            log.write(
                f"S4 original: {s4o['elapsed_seconds']:.3f}s [{s4o['status']}]\n"
            )

            # S4 tail
            s4t = time_s4_tail(rep)
            rows.append(s4t)
            print(f"S4 tail: {s4t['elapsed_seconds']:.3f}s [{s4t['status']}]")
            log.write(
                f"S4 tail: {s4t['elapsed_seconds']:.3f}s [{s4t['status']}]\n"
            )

            # Determinism
            det_start = monotonic()
            det = time_determinism(rep)
            det["elapsed_seconds"] = (
                monotonic() - det_start
            ) / 1e9
            rows.append(det)
            print(
                f"Determinism: {det['elapsed_seconds']:.3f}s [{det['status']}]"
            )
            log.write(
                f"Determinism: {det['elapsed_seconds']:.3f}s "
                f"[{det['status']}]\n"
            )

            # Stage F: complete wall-clock runtime for this repetition.
            total_elapsed = (monotonic() - rep_start) / 1e9

            total = {
                "stage": "total",
                "target": "complete_pipeline",
                "run_id": rep,
                "elapsed_seconds": total_elapsed,
                "returncode": 0,
                "timeout": False,
                "stdout_sha256": "",
                "stderr_sha256": "",
                "status": "PASS",
            }

            rows.append(total)

            print(f"Total pipeline: {total_elapsed:.3f}s [PASS]")
            log.write(
                f"Total pipeline: {total_elapsed:.3f}s [PASS]\n"
            )

    csv_path = write_csv(rows)
    summary = summarize(rows)

    summary_path = RESULTS / "runtime_summary.json"
    summary_path.write_text(
        json.dumps(summary, indent=2, sort_keys=True),
        encoding="utf-8",
    )

    print()
    print("Runtime records:", len(rows))
    print("CSV:", csv_path)
    print("Summary:", summary_path)
    print("Log:", log_path)


if __name__ == "__main__":
    main()
