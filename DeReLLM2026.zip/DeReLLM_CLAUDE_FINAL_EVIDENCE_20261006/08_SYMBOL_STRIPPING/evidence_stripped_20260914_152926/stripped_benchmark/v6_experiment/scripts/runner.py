#!/usr/bin/env python3

import hashlib
import os
import shutil
import subprocess
import tempfile
from pathlib import Path


ENV_KEYS = {
    "PATH",
    "TZ",
    "LC_ALL",
    "LANG",
    "HOME",
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def run_binary(binary, argv, stdin_path=None, timeout=5):
    binary = str(Path(binary).resolve())
    argv = [str(x) for x in argv]

    with tempfile.TemporaryDirectory(prefix="derellm-v6-run-") as td:
        scratch = Path(td)

        env = {
            k: v
            for k, v in os.environ.items()
            if k in ENV_KEYS
        }

        env.update({
            "TZ": "UTC",
            "LC_ALL": "C",
            "LANG": "C",
            "HOME": str(scratch),
            "PATH": "/usr/bin:/bin",
        })

        stdin_handle = None
        try:
            if stdin_path is not None:
                stdin_handle = open(stdin_path, "rb")

            cmd = [
                "setarch",
                "x86_64",
                "-R",
                binary,
                *argv,
            ]

            completed = subprocess.run(
                cmd,
                stdin=stdin_handle,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=scratch,
                env=env,
                timeout=timeout,
                preexec_fn=lambda: os.umask(0o022),
            )

            files_written = {}

            for p in scratch.rglob("*"):
                if p.is_file():
                    rel = str(p.relative_to(scratch))
                    files_written[rel] = sha256_file(p)

            return {
                "stdout_bytes": completed.stdout,
                "stderr_bytes": completed.stderr,
                "exit_status": completed.returncode,
                "files_written": files_written,
            }

        finally:
            if stdin_handle is not None:
                stdin_handle.close()
