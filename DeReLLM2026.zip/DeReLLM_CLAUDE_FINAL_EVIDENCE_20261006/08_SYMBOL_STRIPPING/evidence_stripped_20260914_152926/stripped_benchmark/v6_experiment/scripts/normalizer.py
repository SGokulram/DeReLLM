#!/usr/bin/env python3

import re


HEX_RE = re.compile(
    rb'(?<![A-Za-z0-9])[0-9A-Fa-f]{8,}(?![A-Za-z0-9])'
)

PID_PATTERNS = [
    re.compile(rb'(?i)\bpid[ =:]+[0-9]+\b'),
    re.compile(rb'(?i)\bprocess[ =:]+[0-9]+\b'),
]

FD_RE = re.compile(
    rb'(?i)\b(?:fd|file descriptor)[ =:]+[0-9]+\b'
)

TIMESTAMP_RE = re.compile(
    rb'\b20[0-9]{2}-[0-9]{2}-[0-9]{2}'
    rb'(?:[T ][0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]+)?'
    rb'(?:Z|[+-][0-9]{2}:[0-9]{2})?)?\b'
)


def normalize_bytes(data: bytes) -> bytes:

    data = TIMESTAMP_RE.sub(b'<TIME>', data)
    data = HEX_RE.sub(b'<HEX>', data)

    for pattern in PID_PATTERNS:
        data = pattern.sub(b'<PID>', data)

    data = FD_RE.sub(b'<FD>', data)

    return data


def normalize_capture(capture):
    return {
        "stdout_bytes": normalize_bytes(capture["stdout_bytes"]),
        "stderr_bytes": normalize_bytes(capture["stderr_bytes"]),
        "exit_status": capture["exit_status"],
        "files_written": capture["files_written"],
    }
