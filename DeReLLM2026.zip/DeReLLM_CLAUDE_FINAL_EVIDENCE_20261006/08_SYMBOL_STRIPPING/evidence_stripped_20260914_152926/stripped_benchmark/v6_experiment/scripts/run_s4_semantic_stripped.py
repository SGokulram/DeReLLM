#!/usr/bin/env python3

import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STRIPPED = ROOT.parent
REPO = ROOT.parents[2]

INPUT = ROOT / "runs/s4_evaluator_input.jsonl"
BASELINE = ROOT / "runs/baseline_execution.jsonl"
S1 = ROOT / "runs/s1_execution.jsonl"
CORPUS = ROOT / "corpus/raw"
OUT = ROOT / "runs/s4_verdicts_v4"

OUT.mkdir(parents=True, exist_ok=True)


def load_jsonl(path):
    return [
        json.loads(x)
        for x in path.read_text(encoding="utf-8").splitlines()
        if x.strip()
    ]


baseline = {
    r["input_id"]: r
    for r in load_jsonl(BASELINE)
}

runtime_all = load_jsonl(S1)


def normalize_path(s):
    if not s:
        return s

    return re.sub(
        r"/home/[^:\s]+/(?:"
        r"v6_variants/bin|"
        r"binaries|"
        r"evidence_stripped_[^/\s]+/stripped_benchmark/"
        r"(?:v6_variants/bin|baseline)"
        r")/[^\s:]+",
        "<PROGRAM>",
        s,
    )

def parse_requested_lines(argv):
    if "-n" in argv:
        i = argv.index("-n")
        if i + 1 < len(argv):
            return int(argv[i + 1])

    if argv and argv[0].startswith("-") and argv[0][1:].isdigit():
        return int(argv[0][1:])

    return None


def actual_head_lines(data):
    return data.count(b"\n")


def split_fields(data, delim):
    # Match the original cut.c field semantics for these tests:
    # field count = delimiters + 1.
    lines = data.splitlines()
    return [
        line.decode("utf-8", errors="replace").split(delim)
        for line in lines
    ]


def parse_field_selection(argv):
    if "-f" not in argv:
        return None

    i = argv.index("-f")

    if i + 1 >= len(argv):
        return None

    spec = argv[i + 1]

    finite_max = None

    for part in spec.replace(" ", ",").split(","):
        if not part:
            continue

        if "-" in part:
            left, right = part.split("-", 1)

            if right:
                value = int(right)
                finite_max = (
                    value if finite_max is None
                    else max(finite_max, value)
                )
            else:
                # Open-ended range has no finite highest field.
                return None
        else:
            value = int(part)
            finite_max = (
                value if finite_max is None
                else max(finite_max, value)
            )

    return finite_max


def delimiter_for(argv):
    if "-d" in argv:
        i = argv.index("-d")
        if i + 1 < len(argv):
            return argv[i + 1]

    return "\t"


def req2_allowed(input_id, argv, stderr_changed, stdout_changed, exit_changed):
    data = (CORPUS / f"{input_id}.bin").read_bytes()
    requested = parse_requested_lines(argv)

    # head defaults to 10 lines when no explicit -n option is supplied.
    if requested is None:
        requested = 10

    actual = actual_head_lines(data)

    short = actual < requested

    if not short:
        return False, (
            f"input has {actual} lines and request asks for {requested}; "
            "short-input condition is absent"
        )

    if stderr_changed and not stdout_changed and not exit_changed:
        return True, (
            f"short-input condition holds: actual={actual}, "
            f"requested={requested}"
        )

    return False, (
        "Req2 permits only the short-input stderr diagnostic"
    )


def req5_allowed(
    input_id,
    argv,
    variant_stderr,
    baseline_stderr,
    stdout_changed,
    stderr_changed,
    exit_changed,
):
    if "-f" not in argv:
        return False, "Req5 requires field-selection mode."

    highest = parse_field_selection(argv)

    if highest is None:
        return False, (
            "No finite highest requested field exists for this selection."
        )

    delim = delimiter_for(argv)

    data = (CORPUS / f"{input_id}.bin").read_bytes()

    qualifying = []

    for lineno, fields in enumerate(
        split_fields(data, delim), start=1
    ):
        if len(fields) < highest:
            qualifying.append(lineno)

    if not qualifying:
        return False, (
            "No input line has fewer fields than the highest "
            "requested field."
        )

    # Only stderr may change.
    if stdout_changed or exit_changed:
        return False, (
            "Req5 warning cannot alter stdout or exit status."
        )

    if not (
        stderr_changed
        and variant_stderr != baseline_stderr
    ):
        return False, "No new Req5 diagnostic was observed."

    # Compare only newly introduced line-number diagnostics.
    variant_lines = {
        int(x)
        for x in re.findall(
            r"line\s+([0-9]+)",
            variant_stderr
        )
    }

    baseline_lines = {
        int(x)
        for x in re.findall(
            r"line\s+([0-9]+)",
            baseline_stderr
        )
    }

    new_lines = variant_lines - baseline_lines
    expected = set(qualifying)

    if not expected.issubset(new_lines):
        return False, (
            f"expected warning line(s) {sorted(expected)}, "
            f"observed new line(s) {sorted(new_lines)}"
        )

    return True, (
        f"insufficient-field condition holds on line(s) "
        f"{sorted(expected)}"
    )


def allowed_delta(req, input_id, argv, b, v):
    stdout_changed = v["stdout"] != b["stdout"]

    stderr_changed = (
        normalize_path(v["stderr"])
        != normalize_path(b["stderr"])
    )

    exit_changed = (
        v["exit_status"]
        != b["exit_status"]
    )

    # Nothing changed.
    if not (
        stdout_changed
        or stderr_changed
        or exit_changed
    ):
        return None, None

    # Req1
    if req == 1:
        explicit = parse_requested_lines(argv) is not None

        if (
            not explicit
            and stdout_changed
            and not stderr_changed
            and not exit_changed
        ):
            return True, (
                "default line-count stdout change is permitted"
            )

        return False, "Req1 permits only the default line-count stdout change."

    # Req2
    if req == 2:
        return req2_allowed(
            input_id,
            argv,
            stderr_changed,
            stdout_changed,
            exit_changed,
        )

    # Req3
    if req == 3:
        if (
            argv == ["-n", "0"]
            and exit_changed
            and not stdout_changed
            and not stderr_changed
        ):
            return True, (
                "zero-count exit-status change is permitted"
            )

        return False, (
            "Req3 permits only the zero-count exit-status change."
        )

    # Req4
    if req == 4:
        if (
            "-f" in argv
            and "-d" not in argv
            and stdout_changed
            and not stderr_changed
            and not exit_changed
        ):
            return True, (
                "default delimiter stdout change is permitted"
            )

        return False, (
            "Req4 permits only stdout changes caused by "
            "the default delimiter."
        )

    # Req5
    if req == 5:
        return req5_allowed(
            input_id,
            argv,
            normalize_path(v["stderr"]),
            normalize_path(b["stderr"]),
            stdout_changed,
            stderr_changed,
            exit_changed,
        )

    # Req6
    if req == 6:
        data = (CORPUS / f"{input_id}.bin").read_bytes()
        lines = data.splitlines()

        has_empty = any(len(x) == 0 for x in lines)

        if (
            has_empty
            and stdout_changed
            and not stderr_changed
            and not exit_changed
        ):
            return True, (
                "stdout difference is attributable to removal "
                "of empty input lines"
            )

        return False, (
            "Req6 permits only stdout changes caused by "
            "skipping empty lines."
        )

    return False, "Unhandled request."


def main():
    rows = load_jsonl(INPUT)

    assert len(rows) == 18

    # Fresh output.
    for p in OUT.glob("req*/*.json"):
        p.unlink()

    results = []

    for row in rows:
        req = int(row["request"]["request_id"][3:])
        variant_id = row["variant"]["variant_id"]

        runtime = [
            r
            for r in runtime_all
            if r["variant_id"] == variant_id
        ]

        assert len(runtime) == 40

        explained = []
        unexplained = []

        for vr in runtime:
            b = baseline[vr["input_id"]]

            allowed, reason = allowed_delta(
                req,
                vr["input_id"],
                vr["argv"],
                b,
                vr,
            )

            if allowed is None:
                continue

            record = {
                "input_id": vr["input_id"],
                "argv": vr["argv"],
                "reason": reason,
                "stdout_changed":
                    vr["stdout"] != b["stdout"],
                "stderr_changed":
                    normalize_path(vr["stderr"])
                    != normalize_path(b["stderr"]),
                "exit_changed":
                    vr["exit_status"] != b["exit_status"],
            }

            if allowed:
                explained.append(record)
            else:
                unexplained.append(record)

        # Frozen request-specific test.
        suffix = variant_id.split("_", 1)[1]

        if req <= 3:
            binary = (
                STRIPPED / "v6_variants/bin"
                / f"req{req}"
                / f"head_{suffix}"
            )
        else:
            binary = (
                STRIPPED / "v6_variants/bin"
                / f"req{req}"
                / f"cut_{suffix}"
            )

        test = REPO / "frozen" / f"v6/req{req}/T_R.py"

        p = subprocess.run(
            [sys.executable, str(test), str(binary)],
            capture_output=True,
            text=True,
            timeout=10,
        )

        intent_pass = (
            p.returncode == 0
            and p.stdout.strip() == "PASS"
        )

        verdict = (
            "accept"
            if intent_pass and not unexplained
            else "reject"
        )

        if verdict == "accept":
            rationale = (
                "The frozen intent test passed and every "
                "baseline-relative behavioral difference "
                "is explained by the frozen request."
            )
        else:
            reasons = []

            if not intent_pass:
                reasons.append(
                    "the frozen intent test failed"
                )

            if unexplained:
                reasons.append(
                    f"{len(unexplained)} unexplained "
                    "baseline-relative difference(s) remain"
                )

            rationale = (
                "The variant is rejected because "
                + " and ".join(reasons)
                + "."
            )

        result = {
            "request_id": row["request"]["request_id"],
            "variant_id": variant_id,
            "semantic_verdict": verdict,
            "confidence": 0.995,
            "rationale": rationale,
            "supporting_evidence": [
                f"{len(explained)} explained baseline-relative delta(s)."
            ],
            "contradicting_evidence": [
                f"{len(unexplained)} unexplained delta(s)."
            ] if unexplained else [],
            "intent_test_pass": intent_pass,
            "explained_deltas": explained,
            "unexplained_deltas": unexplained,
            "evaluation_method":
                "baseline-relative dynamic request-condition S4 rubric",
        }

        out_dir = OUT / row["request"]["request_id"]
        out_dir.mkdir(parents=True, exist_ok=True)

        (out_dir / f"{suffix}.json").write_text(
            json.dumps(result, indent=2, sort_keys=True),
            encoding="utf-8",
        )

        results.append(result)

        print(
            f"{variant_id:18} "
            f"intent={'PASS' if intent_pass else 'FAIL':4} "
            f"explained={len(explained):2} "
            f"unexplained={len(unexplained):2} "
            f"=> {verdict}"
        )

    assert len(results) == 18
    print("\nS4 v4 verdicts:", len(results))


if __name__ == "__main__":
    main()
