#!/usr/bin/env python3

import csv
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SB = ROOT.parent
REPO = SB.parent.parent

sys.path.insert(0, str(ROOT / "scripts"))

from runner import run_binary
from normalizer import normalize_capture

CORPUS = ROOT / "runs/deterministic_manifest.jsonl"
VARIANT_ROOT = SB / "v6_variants/bin"
LABEL_ROOT = SB / "v6_variants/evidence"
BASELINE_ROOT = SB / "baseline"

BASELINE_OUT = ROOT / "runs/baseline_execution.jsonl"
S1_OUT = ROOT / "runs/s1_execution.jsonl"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_corpus():
    return [
        json.loads(line)
        for line in CORPUS.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def load_labels():
    labels = {}
    for req in range(1, 7):
        path = LABEL_ROOT / f"req{req}" / "labels.csv"
        with path.open(encoding="utf-8", newline="") as f:
            for r in csv.DictReader(f):
                labels[(r["request_id"], r["variant_id"])] = r
    return labels


def write_record(f, record):
    f.write(json.dumps(record, sort_keys=True) + "\n")
    f.flush()


def run_baselines(corpus):
    if BASELINE_OUT.exists():
        BASELINE_OUT.unlink()

    count = 0

    with BASELINE_OUT.open("w", encoding="utf-8") as fout:
        for rec in corpus:
            program = rec["binary"]

            if program == "head":
                binary = BASELINE_ROOT / "head_baseline"
            elif program == "cut":
                binary = BASELINE_ROOT / "cut_baseline"
            else:
                raise RuntimeError(f"Unknown program: {program}")

            input_path = ROOT / rec["file"]

            capture = normalize_capture(
                run_binary(
                    binary,
                    rec["argv"],
                    str(input_path),
                )
            )

            record = {
                "binary": program,
                "input_id": rec["input_id"],
                "argv": rec["argv"],
                "stdout": capture["stdout_bytes"].decode(
                    "utf-8", errors="replace"
                ),
                "stderr": capture["stderr_bytes"].decode(
                    "utf-8", errors="replace"
                ),
                "stdout_sha256": digest(capture["stdout_bytes"]),
                "stderr_sha256": digest(capture["stderr_bytes"]),
                "exit_status": capture["exit_status"],
                "files_written": capture["files_written"],
            }

            write_record(fout, record)
            count += 1

    print(f"BASELINE executions recorded: {count}")

    if count != 80:
        raise RuntimeError(f"Expected 80 baseline executions, got {count}")


def run_s1(corpus, labels):
    if S1_OUT.exists():
        S1_OUT.unlink()

    variants = []

    for req in range(1, 7):
        req_dir = VARIANT_ROOT / f"req{req}"
        for binary in sorted(req_dir.iterdir()):
            if not binary.is_file():
                continue

            suffix = binary.stem.split("_", 1)[1]
            variant_id = f"req{req}_{suffix}"

            variants.append({
                "request_id": f"req{req}",
                "variant_id": variant_id,
                "binary": binary,
            })

    if len(variants) != 18:
        raise RuntimeError(
            f"Expected 18 stripped variants, found {len(variants)}"
        )

    if len(corpus) != 80:
        raise RuntimeError(
            f"Expected 80 deterministic inputs, found {len(corpus)}"
        )

    expected = 720
    count = 0

    with S1_OUT.open("w", encoding="utf-8") as fout:
        for i, variant in enumerate(variants, 1):
            req = variant["request_id"]
            variant_id = variant["variant_id"]

            label_key = (req, variant_id)
            if label_key not in labels:
                raise RuntimeError(f"Missing label: {req}/{variant_id}")

            label = labels[label_key]

            print(f"[{i:02d}/18] {req}/{variant_id}")

            for rec in corpus:
                if rec["binary"] != variant["binary"].name.split("_")[0]:
                    continue

                input_path = ROOT / rec["file"]

                capture = normalize_capture(
                    run_binary(
                        variant["binary"],
                        rec["argv"],
                        str(input_path),
                    )
                )

                out_b = capture["stdout_bytes"]
                err_b = capture["stderr_bytes"]

                record = {
                    "request_id": req,
                    "variant_id": variant_id,
                    "label": label["label"],
                    "expected_verdict": label["expected_verdict"],
                    "input_id": rec["input_id"],
                    "argv": rec["argv"],
                    "stdout": out_b.decode("utf-8", errors="replace"),
                    "stderr": err_b.decode("utf-8", errors="replace"),
                    "stdout_sha256": digest(out_b),
                    "stderr_sha256": digest(err_b),
                    "exit_status": capture["exit_status"],
                    "files_written": capture["files_written"],
                }

                write_record(fout, record)
                count += 1

                if count % 50 == 0:
                    print(f"  progress: {count}/{expected}")

    print(f"S1 executions recorded: {count}")

    if count != expected:
        raise RuntimeError(
            f"Expected {expected} S1 executions, got {count}"
        )


def main():
    corpus = load_corpus()
    labels = load_labels()

    print("==============================================")
    print("DeReLLM STRIPPED BENCHMARK")
    print("18 variants × 40 matching cases = 720 S1")
    print("==============================================")

    run_baselines(corpus)
    run_s1(corpus, labels)


if __name__ == "__main__":
    main()
