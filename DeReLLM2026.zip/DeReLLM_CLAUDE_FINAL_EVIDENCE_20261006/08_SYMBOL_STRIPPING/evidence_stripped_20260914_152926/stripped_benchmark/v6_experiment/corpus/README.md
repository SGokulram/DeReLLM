# DeReLLM v6 Determinism Corpus

Frozen corpus:
- 40 head cases
- 40 cut cases
- 80 total input cases
- No duplicate input_id values
- All manifest-referenced files exist

The corpus is frozen before determinism screening.
