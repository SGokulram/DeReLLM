# DeReLLM Stripped-vs-Unstripped Ablation

## Purpose

Evaluate whether removing ELF symbol/debug information changes DeReLLM's
binary-patch verification outcome under the frozen v6 benchmark protocol.

## Controlled variable

Unstripped ELF binaries versus copies transformed using:

`strip --strip-all`

All request definitions, labels, deterministic inputs, S1 runner behavior,
S4 semantic rubric, frozen intent tests, and evaluation conditions were held
constant.

## Dataset

- 6 requests
- 18 labeled variants
- 3 variants per request
- 80 deterministic inputs
- 720 stripped S1 executions
- 80 stripped baseline executions

## Stripped results

- TP: 6
- TN: 12
- FP: 0
- FN: 0
- Accuracy: 1.0000
- Precision: 1.0000
- Recall: 1.0000
- F1: 1.0000
- Final verdicts matching gold: 18/18

## Comparison

| Metric | Unstripped | Stripped | Delta |
|---|---:|---:|---:|
| Accuracy | 1.0000 | 1.0000 | 0.0000 |
| Precision | 1.0000 | 1.0000 | 0.0000 |
| Recall | 1.0000 | 1.0000 | 0.0000 |
| F1 | 1.0000 | 1.0000 | 0.0000 |

Confusion matrix is identical in both conditions:

- TP = 6
- TN = 12
- FP = 0
- FN = 0

## Interpretation

On this frozen 18-variant benchmark, stripping ELF symbol/debug information
produced no change in the final binary-patch verification decisions.

This result supports robustness of the evaluated verification pipeline to
stripping on this benchmark. It does not establish that stripping cannot
affect verification for other binaries, patch classes, binaries requiring
symbols for analysis, or larger benchmarks.

## Evidence chain

Raw binaries -> execution captures -> S1 records -> S4 verdicts ->
classification summary -> unstripped/stripped comparison.

See the SHA-256 manifest in:

`hashes/all_evidence_sha256.txt`
