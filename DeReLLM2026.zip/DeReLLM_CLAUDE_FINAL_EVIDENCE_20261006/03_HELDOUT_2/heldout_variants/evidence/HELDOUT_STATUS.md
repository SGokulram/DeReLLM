# Held-Out / Reachability-Limited Experiment Status

Status: COMPLETE

Two held-out mutants were constructed from their corresponding
request-specific correct implementations.

## HEAD

Variant: head_ARGNUM
Request: req1
Mutation: ARGNUMF() -> ARGNUMF()

Matching frozen cases:
- 9

Observable divergences on matching frozen cases:
- 0

A dedicated targeted probe demonstrates observable behavioral change
when the ARGNUM path is explicitly exercised.

## CUT

Variant: cut_EMPTY_LIST
Request: req6
Mutation: suppress empty-list diagnostic

Matching frozen cases:
- 9

Observable divergences on matching frozen cases:
- 0

A dedicated targeted probe demonstrates observable behavioral change
when the empty-list path is explicitly exercised.

## Aggregate

Corresponding frozen cases tested: 18
Observable divergences: 0
Unchanged: 18

The held-out mutants were not used to construct, select, or regenerate
the frozen circularity dataset.

This result should be described as 0/18 observable divergences on the
corresponding frozen cases, not as proof of universal mathematical
unreachability.

Targeted-probe evidence is stored in:
- HELDOUT_TARGETED_PROBES.json
