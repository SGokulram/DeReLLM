# DeReLLM Evidence Status

## Confirmed

Core 18:
req1 head
req2 head
req3 head
req4 cut
req5 cut
req6 cut

Each has correct / Family A / Family B variants.

Tail extension 6:
req7 tail correct / Family A / Family B
req8 tail correct / Family A / Family B

Held-out reachability cases are separate.

## Required audit items

The following are searched for but must not be fabricated if absent:

- Qwen/model proposal outputs
- proposal prompts/seeds/manual judgments
- reasoning-only raw outputs
- determinism artifacts
- tail determinism
- held-out final verifier verdicts
- T_R / E(R) implementation
- exact tool/model/RAG/timeout record
- second-rater data

All search results are preserved under 16_DISCOVERY_REPORTS.
