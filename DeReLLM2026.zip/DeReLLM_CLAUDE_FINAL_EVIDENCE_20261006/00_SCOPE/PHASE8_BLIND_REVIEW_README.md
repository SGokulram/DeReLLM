# DeReLLM v6 Phase-8 Blind Proposer Review

This file accompanies `phase8_v6_blind_review.jsonl`.

Protocol:
- 6 frozen change requests
- 3 proposer runs per request
- 18 generated proposals total
- Model: qwen2.5-coder:7b
- Temperature: 0
- Context: 4096

The reviewer receives:
- request
- expected behavior
- original Ghidra pseudocode
- generated proposal

The reviewer does NOT receive:
- benchmark gold family labels
- S1 runtime evidence
- S3 static evidence
- S4 verifier verdicts
- benchmark variant identities

Manual adjudication fields:
- semantic_verdict
- confidence
- rationale
- satisfies_request
- unrelated_change

Do not copy S4 verdicts into this review.
Do not infer gold labels from request numbering.
Do not alter generated proposals.

The proposer experiment is separate from the reasoning-only
ablation and is intended for the §VII-C end-to-end case study.
