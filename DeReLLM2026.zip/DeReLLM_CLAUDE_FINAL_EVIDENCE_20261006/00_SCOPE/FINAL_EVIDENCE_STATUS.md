# DeReLLM Final Evidence Status

## Authoritative benchmark lineage

The final core benchmark is the frozen v6 lineage:

- `v6_experiment`
- `v6_variants`
- requests `req1` through `req6`
- 18 core variants
- 3 variants per request:
  - Correct
  - Family A
  - Family B

The tail extension contains:

- `req7`
- `req8`
- 6 additional variants

The combined labelled benchmark therefore contains 24 variants:

- 8 correct
- 8 Family A
- 8 Family B

The two held-out reachability cases are separate from this 24-case
labelled benchmark.

## Authoritative core result

From `decision_log_v6.jsonl`:

- TP = 6
- TN = 12
- FP = 0
- FN = 0
- Accuracy = 100%
- Precision = 100%
- Recall = 100%
- F1 = 100%

## Important implementation limitation

S2 was not executed in the reported experiment.

S3 is only a prototype/stub in the reported implementation and does
not provide a real structural comparison. Its zero catches therefore
must not be interpreted as evidence that structural invariants were
experimentally validated.

The reported fault-family attribution is based on the actually executed
signals, principally S1 and S4.

## Held-out reachability cases

The two held-out reachability faults are:

- `req1_head_ARGNUM`
- `req6_cut_EMPTY_LIST`

Both were falsely accepted.

Observed outcome:

- false accepts = 2
- held-out cases = 2
- observed FAR on this tiny held-out set = 2/2

This is reported only as a demonstrated blind spot. It is NOT presented
as a general FAR estimate because n = 2.

## LLM proposer case study

Canonical Phase 8 evidence contains:

- 18 proposals
- 6 frozen requests
- 3 seeds per request
- Qwen2.5-Coder 7B
- temperature = 0
- generation failures = 0

Completed adjudication:

- ACCEPT = 5
- REJECT = 13
- acceptance rate = 5/18 = 27.78%

Request-level acceptance:

- req1 = 3/3
- req2 = 0/3
- req3 = 0/3
- req4 = 0/3
- req5 = 0/3
- req6 = 2/3

### Blind-review status

`phase8_v6_blind_review.jsonl` is a review template whose semantic
verdicts remain `PENDING`.

No completed independent second-rater dataset or inter-rater agreement
result was found in the repository search.

Therefore this package does NOT claim completed double-blind
adjudication or inter-rater agreement for Phase 8.

## Superseded artifacts

Older result files are preserved under:

`15_RESULT_AUDIT/SUPERSEDED/`

These files are included for reproducibility/auditability but are not
authoritative for the final reported benchmark metrics.
