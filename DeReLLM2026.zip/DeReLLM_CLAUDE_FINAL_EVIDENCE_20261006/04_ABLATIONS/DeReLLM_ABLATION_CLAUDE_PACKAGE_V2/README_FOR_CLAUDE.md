# DeReLLM — FINAL V2 ABLATION EVIDENCE

This package contains the FINAL authoritative S1/S4 ablation
evidence for the DeReLLM manuscript.

IMPORTANT:
- Use V2 files in this package as authoritative.
- Do not use the older V1 ablation logs for manuscript numbers.
- Do not reconstruct or infer ablation numbers.
- Do not change the frozen benchmark.

## Frozen benchmark

- 2 binaries: head, cut
- 18 variants
- 6 correct
- 6 Family A
- 6 Family B

The benchmark was SHA-256 frozen before the ablation.

## Final measured results

| Configuration | TP | FN | FP | TN | FAR | Accuracy |
|---|---:|---:|---:|---:|---:|---:|
| S1-only | 5 | 1 | 2 | 10 | 16.7% | 83.3% |
| S4-only | 6 | 0 | 6 | 6 | 50.0% | 66.7% |
| S1+S4 | 6 | 0 | 0 | 12 | 0.0% | 100.0% |

Family coverage:

| Configuration | Family A | Family B |
|---|---:|---:|
| S1-only | 4/6 | 6/6 |
| S4-only | 6/6 | 0/6 |
| S1+S4 | 6/6 | 6/6 |

## Correct interpretation

Use:

"S1 and S4 provide complementary but partially overlapping coverage
on this benchmark."

Do NOT describe the coverage as a clean partition of the two fault
families.

A useful explanatory observation is:

- S1-only catches all 6 Family B faults and 4/6 Family A faults.
- S4-only catches all 6 Family A faults and 0/6 Family B faults.
- S1+S4 catches all 12 faulty variants while accepting all 6 correct
  variants.

## S1-only false negative

S1-only rejects `req6_correct` because no differential divergence is
observed under the S1-only inertness rule.

The combined S1+S4 verifier accepts that same correct variant because
T_R passes and there are no unexplained divergences.

Do not hide this case; it is part of the measured behavior and should
be described consistently with Protocol V2.

## Important semantic distinction

S1-only:
- at least one divergence;
- all observed divergences must be allowed by E(R);
- no T_R evidence.

S4-only:
- T_R PASS -> ACCEPT;
- T_R FAIL -> REJECT;
- no S1 evidence.

S1+S4:
- no unexplained baseline-relative divergence;
- T_R must pass;
- zero divergence is not itself a rejection in the combined mode.

## Regression

The final V2 S1+S4 regression reproduced the frozen gold labels:

TP=6, FN=0, FP=0, TN=12.

This is a reproducibility gate, not a separate scientific finding.

## Determinism

Existing benchmark screening:
- 80 inputs
- 5 runs per input
- 400 executions
- 80 deterministic
- 0 excluded

This is existing benchmark-screen evidence, not a new ablation run.

## Wilson 95% CIs

Aggregate only:

S1-only:
- FAR [4.7%, 44.8%]
- Accuracy [60.8%, 94.2%]

S4-only:
- FAR [25.4%, 74.6%]
- Accuracy [43.7%, 83.7%]

S1+S4:
- FAR [0.0%, 24.2%]
- Accuracy [82.4%, 100.0%]

Do not report CIs for subgroups with n <= 6.

## Manuscript action

Replace the old derived/reconstructed S1/S4 ablation table with the
measured V2 ablation.

Update the related discussion in the experimental and results
sections.

Remove language implying that the old derived 41.7% S1-only FAR was
measured.

Preserve the benchmark limitations:
- constructed benchmark;
- 18 variants;
- 2 binaries;
- small n;
- no broad generalization claim.

Preserve signal scope:
- S1 implemented
- S4 implemented
- S3 static-only
- S2 deferred/unimplemented

Keep essential VeriBin/related-work positioning.

## Final numbers authority

The authoritative numerical source is:
`analysis/ABLATION_RESULTS_V2.json`

The authoritative raw results are:
`s1/results.jsonl`
`s4/results.jsonl`
`s1_plus_s4/results.jsonl`

The exact runner used is:
`scripts/run_ablation_v1.py`

## Non-negotiable

Measured results override historical derived values.

Do not invent, smooth, improve, or reinterpret the measured results.
