# DeReLLM v6 — S1/S4 Real Ablation Protocol v2

## Scope

Frozen benchmark:
- 2 binaries: head, cut
- 18 variants total
- 6 correct
- 6 Family A
- 6 Family B

The benchmark artifacts, labels, requests, T_R, E(R), input corpus,
normalization rules, and build artifacts are immutable.

## S1-only

Use the S1 differential-I/O evidence and frozen E(R).

Decision:
- if zero divergence is observed, REJECT (inert under S1-only);
- if any observed divergence is outside E(R), REJECT;
- otherwise ACCEPT.

No T_R evidence is used.

## S4-only

Use only the frozen T_R intent test.

Decision:
- T_R PASS -> ACCEPT;
- T_R FAIL -> REJECT.

No S1 evidence is used.
The S1 divergence-based inert rule is not applied.

## S1+S4

Use the combined verifier rule:

- reject if any baseline-relative divergence is unexplained by E(R);
- otherwise require T_R PASS.

A zero-divergence case is not rejected solely for being inert when
the S4 intent test passes.

Thus the combined configuration is not defined as applying the
S1-only verdict plus S4; it uses the combined acceptance rule above.

## Pre-commitment

Historical derived values are not targets.

Measured results from the v2 runs are authoritative.

No cherry-picking, post-hoc tuning, or protocol changes after observing
the v2 results are permitted.

## Provenance

Every result record must include:
- configuration;
- request_id;
- variant_id;
- gold label/verdict;
- timestamp;
- runner Git commit;
- runner SHA-256;
- protocol SHA-256;
- binary SHA-256.

## Regression discrepancy procedure

Run S1+S4 first.

If any variant differs from the historical result:
1. identify the mismatched variant;
2. compare historical and v2 outputs;
3. independently verify the frozen ground-truth label;
4. determine whether the implementation or historical result is wrong;
5. document the adjudication.

Do not modify the implementation merely to reproduce a historical value.

## Interpretation

The primary interpretation is determined by the measured results.

For the current observed pattern, the appropriate wording is:

"S1 and S4 provide complementary but partially overlapping coverage
on this benchmark."

Do not claim universal complementarity, statistical superiority, or
broad generalization.

## Statistical reporting

Report Wilson 95% confidence intervals only for aggregate FAR and
aggregate accuracy.

Do not report confidence intervals for per-family or
per-modification subgroups (n <= 6).

## Determinism

The benchmark's existing N=5 screen is reported separately as
benchmark-screen evidence, not as a new ablation execution.

## Signal scope

- S1: implemented
- S4: implemented
- S3: static-only
- S2: deferred/unimplemented

