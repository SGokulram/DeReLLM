# DeReLLM — Claude Ablation Evidence Handoff

## Purpose

This package contains the authoritative evidence for the real S1/S4
ablation performed on the frozen 18-variant DeReLLM v6 benchmark.

The package is intended to update the existing manuscript without
inventing or reconstructing experimental results.

## Canonical measured results

| Configuration | TP | FN | FP | TN | FAR | Accuracy |
|---|---:|---:|---:|---:|---:|---:|
| S1-only | 5 | 1 | 2 | 10 | 16.7% | 83.3% |
| S4-only | 6 | 0 | 6 | 6 | 50.0% | 66.7% |
| S1+S4 | 6 | 0 | 0 | 12 | 0.0% | 100.0% |

Family coverage:

| Configuration | Family A | Family B |
|---|---:|---:|
| S1-only | 4/6 | 6/6 |
| S4-only | 6/6 | 0/6 |
| S1+S4 | 6/6 | 6/6 |

## Required manuscript change

Replace the old DERIVED/RECONSTRUCTED S1/S4 attribution table with a
measured ablation table using the canonical values above.

Do not reuse the old 41.7% S1-only FAR as a measured result.

Do not describe S1-only, S4-only, and S1+S4 as "experimentally
compared" unless the wording is clearly referring to the new measured
ablation documented here.

## Recommended interpretation

The measured ablation confirms complementary coverage of S1 and S4
on the frozen benchmark.

S4 rejects all Family A faults but accepts all Family B faults.
S1 rejects all Family B faults and 4/6 Family A faults.
Their combination rejects all 12 faulty variants while accepting all
6 correct variants.

Keep this conclusion benchmark-specific.

## Scope and limitations

The benchmark contains:
- 2 binaries
- 18 constructed variants
- 6 correct
- 6 Family A
- 6 Family B

Therefore, the result demonstrates benchmark-level feasibility and
signal complementarity, not broad statistical generalization.

## Statistical reporting

Aggregate Wilson 95% confidence intervals:

S1-only:
- FAR [4.7%, 44.8%]
- Accuracy [60.8%, 94.2%]

S4-only:
- FAR [25.4%, 74.6%]
- Accuracy [43.7%, 83.7%]

S1+S4:
- FAR [0.0%, 24.2%]
- Accuracy [82.4%, 100.0%]

Do not add confidence intervals to per-family or per-modification
subgroups.

## Determinism evidence

The original benchmark screening contains:
- 80 inputs
- 5 repetitions per input
- 400 executions
- 80 deterministic/included
- 0 excluded

This is existing benchmark-screen evidence, not a new ablation run.

## Signal scope

- S1: implemented
- S4: implemented
- S3: static-only
- S2: deferred/unimplemented

No S2 empirical conclusion should be added.

## Evidence authority

The authoritative numerical source is:

`analysis/ABLATION_RESULTS_V1.json`

The authoritative raw sources are:

`s1/results.jsonl`
`s4/results.jsonl`
`s1_plus_s4/results.jsonl`

Use the checksum files to verify integrity.

## Non-negotiable rule

Measured results override all historical derived values.

Do not fabricate an execution, result, comparison, or statistical
claim not supported by this package.

## Ablation implementation

The exact isolated ablation runner used to generate the reported
results is included at:

`scripts/run_ablation_v1.py`

Its SHA-256 must be recorded in the package checksum manifest.

The runner reuses the existing request-specific divergence/E(R)
logic and executes the frozen T_R for S4 configurations. It does not
modify the frozen benchmark artifacts.
