# DeReLLM v6 Phase 3 — Determinism Screening

Corpus:
- 40 head cases
- 40 cut cases
- 80 total

Repeated runs per case:
- N = 5

Total executions:
- 400

Results:
- Deterministic/included: 80
- Excluded: 0

All cases produced identical normalized:
- stdout
- stderr
- exit status
- generated-file observations

The resulting deterministic manifest is:
runs/deterministic_manifest.jsonl

The raw screening evidence is:
runs/phase3_screen.jsonl
