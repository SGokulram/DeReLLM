# DeReLLM v6 — Real S1/S4 Ablation Evidence

## STATUS

This document is the human-readable index for the real ablation
performed on the frozen DeReLLM v6 benchmark.

The benchmark was frozen before the ablation using the committed
SHA-256 manifest.

NO benchmark variants, labels, requests, T_R definitions, E(R),
input corpus, or build artifacts were changed for the ablation.

---

## 1. FROZEN BENCHMARK

- Binaries: 2
  - head
  - cut
- Total variants: 18
- Correct variants: 6
- Family A faults: 6
- Family B faults: 6
- S1 observations: 720
- S1 observations per variant: 40
- Baseline observations: 80

Freeze manifest:

`freeze/SHA256SUMS_FROZEN_18_PATCH_BENCHMARK.txt`

---

## 2. EXPERIMENTAL CONFIGURATIONS

### S1-only

Uses behavioral differential evidence and E(R).

Decision:
- at least one divergence must be observed;
- every observed divergence must be allowed by E(R);
- no T_R evidence is used.

### S4-only

Uses only the frozen T_R intent test.

Decision:
- T_R PASS -> ACCEPT
- T_R FAIL -> REJECT

No S1 evidence is used.
The S1 divergence-based inert rule is not applied.

### S1+S4

Uses the combined acceptance rule:

- no unexplained baseline-relative divergence;
- T_R must pass.

---

## 3. REGRESSION RESULT

The refactored S1+S4 configuration was executed on all 18 frozen
variants and reproduced the expected gold-label behavior:

- TP = 6
- FN = 0
- FP = 0
- TN = 12
- FAR = 0/12 = 0%
- Accuracy = 18/18 = 100%

This regression is a reproducibility/provenance check, not an
independent scientific claim.

Raw result:

`s1_plus_s4/results.jsonl`

---

## 4. REAL S1-ONLY RESULT

Executed on all 18 frozen variants.

- TP = 5
- FN = 1
- FP = 2
- TN = 10
- FAR = 2/12 = 16.7%
- Accuracy = 15/18 = 83.3%

Family coverage:
- Family A: 4/6 caught
- Family B: 6/6 caught

Raw result:

`s1/results.jsonl`

---

## 5. REAL S4-ONLY RESULT

Executed on all 18 frozen variants using the frozen T_R.

- TP = 6
- FN = 0
- FP = 6
- TN = 6
- FAR = 6/12 = 50.0%
- Accuracy = 12/18 = 66.7%

Family coverage:
- Family A: 6/6 caught
- Family B: 0/6 caught

Raw result:

`s4/results.jsonl`

---

## 6. COMBINED RESULT

The measured S1+S4 result was:

- TP = 6
- FN = 0
- FP = 0
- TN = 12
- FAR = 0%
- Accuracy = 100%

Family coverage:
- Family A: 6/6 caught
- Family B: 6/6 caught

---

## 7. AGGREGATE WILSON 95% CONFIDENCE INTERVALS

S1-only:
- FAR: [4.7%, 44.8%]
- Accuracy: [60.8%, 94.2%]

S4-only:
- FAR: [25.4%, 74.6%]
- Accuracy: [43.7%, 83.7%]

S1+S4:
- FAR: [0.0%, 24.2%]
- Accuracy: [82.4%, 100%]

Do not report Wilson intervals for per-family or per-modification
subgroups because each subgroup has n <= 6.

---

## 8. CENTRAL INTERPRETATION

The measured ablation supports the following statement:

"S1 and S4 provide complementary coverage on the frozen benchmark.
S4 rejects all Family A faults but accepts all Family B faults,
whereas S1 rejects all Family B faults and additionally rejects
four of six Family A faults. Their combination rejects all 12 faulty
variants while accepting all six correct variants."

This is a benchmark-specific feasibility result.

It must NOT be generalized to arbitrary binaries or patch corpora.

---

## 9. IMPORTANT PAPER WORDING

Recommended paper wording:

"Ablation of verification signals. We evaluated the same frozen set
of 18 variants using three configurations: S1-only, S4-only, and the
combined S1+S4 verifier. S1-only accepted 5/6 correct variants and
rejected 10/12 faulty variants, yielding 2/12 false accepts (16.7%)
and 83.3% accuracy. S4-only accepted all 6 correct variants but
rejected only 6/12 faulty variants, yielding 6/12 false accepts
(50.0%) and 66.7% accuracy. The combined S1+S4 configuration
accepted all 6 correct variants and rejected all 12 faulty variants,
yielding 0/12 false accepts and 100% accuracy on this benchmark."

Recommended interpretation:

"The measured ablation confirms the intended complementary coverage
of S1 and S4 on this benchmark."

Recommended limitation:

"The benchmark contains 18 constructed variants across two binaries,
so the ablation demonstrates feasibility and signal complementarity
rather than broad statistical generalization."

---

## 10. DO NOT CLAIM

Do not claim:
- that the three configurations were statistically proven superior;
- universal complementarity;
- generalization beyond the benchmark;
- a larger benchmark than 18 variants;
- a larger number of binaries than two;
- any S2 experimental result;
- any S3 result beyond its implemented static scope.

Do not describe the old 41.7% / 50.0% derived table as measured data.
The new measured results are authoritative.

---

## 11. PROVENANCE

Initial runner commit:

`d99925a7c4cadb48df5adbe6ed27f9b7b59fbbe0`

Subsequent runner corrections:
- `c19b93d2e0b35c84b4527033345441ff6800c551`
- `3c5202c574b9e28441f278a1e656e956735ae2ac`
- `fbc848d8d9c7e648a37701a1d2109a7f227ce9fd`

Freeze commit:

`fbb53cd638b3e2637590976b3417d5e07a5edc78`

Ablation protocol commit:

`8e6e8aa9b0719dc898af152ca7592bd8d3ccb95c`

The final runner was subsequently corrected for manifest metadata
mapping and committed as:

`3c5202c574b9e28441f278a1e656e956735ae2ac`

The combined decision rule was subsequently corrected and committed as:

`fbc848d8d9c7e648a37701a1d2109a7f227ce9fd`

The final runner SHA-256 should be recorded separately from this
document.

---

## 12. AUTHORITATIVE RAW ARTIFACTS

- `s1/results.jsonl`
- `s4/results.jsonl`
- `s1_plus_s4/results.jsonl`
- `analysis/ABLATION_RESULTS_V1.json`
- `protocol/ABLATION_PROTOCOL.md`
- `freeze/SHA256SUMS_FROZEN_18_PATCH_BENCHMARK.txt`

When writing the paper, every reported numerical result must be
traceable to these artifacts.


## 13. DETERMINISM EVIDENCE

The benchmark corpus underwent an N=5 determinism screen as part of
the original benchmark construction.

Measured evidence:
- 80 inputs screened
- 5 executions per input
- 400 total executions
- 80 deterministic/included
- 0 excluded

The screen compared normalized stdout, stderr, exit status, and
generated-file observations across the five repetitions.

Raw evidence:
- `../phase3_screen.jsonl`
- `../deterministic_manifest.jsonl`
- `../excluded_manifest.jsonl`
- `../PHASE3_SUMMARY.md`

This is existing benchmark-screen evidence, not a new ablation run.
