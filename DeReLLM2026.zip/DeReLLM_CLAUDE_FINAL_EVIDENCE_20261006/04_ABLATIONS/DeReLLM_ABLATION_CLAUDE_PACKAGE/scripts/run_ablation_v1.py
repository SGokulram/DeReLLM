#!/usr/bin/env python3

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent

MANIFEST = ROOT / "runs/v6_variants_manifest.json"
S1_PATH = ROOT / "runs/s1_execution.jsonl"
BASELINE_PATH = ROOT / "runs/baseline_execution.jsonl"
FREEZE = ROOT / "runs/ablation_v1/freeze/SHA256SUMS_FROZEN_18_PATCH_BENCHMARK.txt"
FROZEN_ROOT = REPO / "frozen/v6"
OUT_ROOT = ROOT / "runs/ablation_v1"

sys.path.insert(0, str(ROOT / "scripts"))
from run_s4_semantic_v4 import allowed_delta


def load_jsonl(path: Path):
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_freeze():
    if not FREEZE.exists():
        raise SystemExit(f"Missing freeze manifest: {FREEZE}")

    errors = []

    for line in FREEZE.read_text(encoding="utf-8").splitlines():
        if not line or line.startswith("#") or line.startswith("##"):
            continue

        try:
            expected_hash, rel_path = line.split("  ", 1)
        except ValueError:
            raise SystemExit(f"Malformed freeze-manifest line: {line}")

        path = REPO / rel_path

        if not path.exists():
            errors.append(f"MISSING: {rel_path}")
            continue

        actual_hash = sha256_file(path)

        if actual_hash != expected_hash:
            errors.append(
                f"HASH MISMATCH: {rel_path}\n"
                f"  expected: {expected_hash}\n"
                f"  actual:   {actual_hash}"
            )

    if errors:
        raise SystemExit(
            "FROZEN INPUT VERIFICATION FAILED:\n"
            + "\n".join(errors)
        )


def load_inputs():
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))

    variants = [
        v
        for request in manifest["requests"]
        for v in request["variants"]
    ]

    s1_rows = load_jsonl(S1_PATH)

    baseline_rows = load_jsonl(BASELINE_PATH)
    baseline = {
        row["input_id"]: row
        for row in baseline_rows
    }

    if len(variants) != 18:
        raise SystemExit(
            f"Expected 18 manifest variants, got {len(variants)}"
        )

    if len(s1_rows) != 720:
        raise SystemExit(
            f"Expected 720 S1 records, got {len(s1_rows)}"
        )

    s1_by_variant = {}

    for row in s1_rows:
        s1_by_variant.setdefault(row["variant_id"], []).append(row)

    if len(s1_by_variant) != 18:
        raise SystemExit(
            f"Expected 18 unique S1 variants, got {len(s1_by_variant)}"
        )

    bad = {
        variant_id: len(rows)
        for variant_id, rows in s1_by_variant.items()
        if len(rows) != 40
    }

    if bad:
        raise SystemExit(
            f"S1 record-count check failed: {bad}"
        )

    return manifest, variants, s1_by_variant, baseline


def run_tr(req: int, binary: Path):
    test = FROZEN_ROOT / f"req{req}" / "T_R.py"

    if not test.exists():
        raise SystemExit(f"Missing T_R: {test}")

    completed = subprocess.run(
        [sys.executable, str(test), str(binary)],
        capture_output=True,
        text=True,
        timeout=10,
    )

    passed = (
        completed.returncode == 0
        and completed.stdout.strip() == "PASS"
    )

    return {
        "pass": passed,
        "returncode": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }


def evaluate_s1(req: int, runtime_rows, baseline):
    divergences = []

    for variant_row in runtime_rows:
        input_id = variant_row["input_id"]

        if input_id not in baseline:
            raise SystemExit(
                f"Missing baseline record for input {input_id}"
            )

        allowed, reason = allowed_delta(
            req,
            input_id,
            variant_row["argv"],
            baseline[input_id],
            variant_row,
        )

        if allowed is None:
            continue

        divergences.append({
            "input_id": input_id,
            "argv": variant_row["argv"],
            "allowed": bool(allowed),
            "reason": reason,
            "stdout_changed":
                variant_row["stdout"] != baseline[input_id]["stdout"],
            "stderr_changed":
                variant_row["stderr"] != baseline[input_id]["stderr"],
            "exit_changed":
                variant_row["exit_status"]
                != baseline[input_id]["exit_status"],
        })

    unexplained = [
        record
        for record in divergences
        if not record["allowed"]
    ]

    # Frozen protocol:
    # at least one divergence must exist, and all divergence must
    # be explained by E(R).
    accepted = (
        len(divergences) > 0
        and len(unexplained) == 0
    )

    return {
        "divergence_count": len(divergences),
        "unexplained_count": len(unexplained),
        "divergences": divergences,
        "verdict": "accept" if accepted else "reject",
    }


def main():
    parser = argparse.ArgumentParser(
        description="DeReLLM v6 S1/S4 ablation runner"
    )

    parser.add_argument(
        "--signals",
        required=True,
        choices=("s1", "s4", "s1+s4"),
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate frozen inputs without evaluating variants.",
    )

    args = parser.parse_args()

    print(f"Configuration: {args.signals}")
    print("Verifying frozen inputs...")

    verify_freeze()

    manifest, variants, s1_by_variant, baseline = load_inputs()

    print("Frozen inputs: VERIFIED")
    print(f"Variants: {len(variants)}")
    print(f"S1 records: {sum(len(v) for v in s1_by_variant.values())}")
    print(f"Baseline records: {len(baseline)}")

    output_dir = (
        OUT_ROOT
        / args.signals.replace("+", "_plus_")
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    if args.dry_run:
        print("DRY RUN OK")
        print(f"Output directory: {output_dir}")
        return

    results = []

    for index, item in enumerate(
        (
            (request, variant)
            for request in manifest["requests"]
            for variant in request["variants"]
        ),
        start=1,
    ):
        request, variant = item
        req = int(request["request_id"][3:])
        variant_id = variant["variant_id"]
        family = variant["label"]
        binary = REPO / variant["binary"]

        row = {
            "configuration": args.signals,
            "request_id": request["request_id"],
            "variant_id": variant_id,
            "family": family,
            "gold_verdict": (
                "accept"
                if family == "correct"
                else "reject"
            ),
            "binary_sha256": sha256_file(binary),
        }

        s1_result = None
        s4_result = None

        if args.signals in ("s1", "s1+s4"):
            s1_result = evaluate_s1(
                req,
                s1_by_variant[variant_id],
                baseline,
            )
            row["s1"] = s1_result

        if args.signals in ("s4", "s1+s4"):
            s4_result = run_tr(req, binary)
            row["s4"] = s4_result

        if args.signals == "s1":
            final_verdict = s1_result["verdict"]

        elif args.signals == "s4":
            final_verdict = (
                "accept"
                if s4_result["pass"]
                else "reject"
            )

        else:
            # Existing combined S1+S4 rule:
            # T_R must pass and there must be no unexplained
            # baseline-relative divergence. The S1-only inert
            # requirement is NOT applied here.
            final_verdict = (
                "accept"
                if (
                    s1_result["unexplained_count"] == 0
                    and s4_result["pass"]
                )
                else "reject"
            )

        row["final_verdict"] = final_verdict

        results.append(row)

        print(
            f"[{index:02d}/18] "
            f"{variant_id:18} "
            f"=> {final_verdict.upper()}"
        )

    output = output_dir / "results.jsonl"

    output.write_text(
        "\n".join(
            json.dumps(row, sort_keys=True)
            for row in results
        ) + "\n",
        encoding="utf-8",
    )

    print()
    print(f"Results written: {output}")
    print(f"Variants evaluated: {len(results)}")


if __name__ == "__main__":
    main()
