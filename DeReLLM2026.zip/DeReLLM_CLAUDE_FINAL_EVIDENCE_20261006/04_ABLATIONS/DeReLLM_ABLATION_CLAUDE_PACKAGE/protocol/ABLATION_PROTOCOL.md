# DeReLLM v6 — S1/S4 Real Ablation Protocol

## Scope

Frozen benchmark:
- 2 binaries: head, cut
- 18 variants total
- 6 correct
- 6 Family A
- 6 Family B

The frozen benchmark artifacts, labels, requests, T_R, E(R),
input corpus, normalization rules, and build artifacts must not change.

## Configurations

### S1-only

Use S1 behavioral divergence evidence and E(R).

Decision:
- REJECT if no divergence is observed (inert patch).
- REJECT if any observed divergence is outside E(R).
- ACCEPT only if at least one divergence exists and every divergence is within E(R).

Do not use T_R evidence.

### S4-only

Use only the frozen T_R.

Decision:
- ACCEPT iff T_R passes.
- REJECT iff T_R fails.

Do not use S1 evidence.
Do not apply the divergence-based inert-patch rule.

### S1+S4

Use the existing combined acceptance rule unchanged.

## Pre-commitment

Previously derived values (including 41.7% S1-only FAR and
50.0% S4-only FAR) are expectations only, not targets.

Measured results from the new runs are authoritative.

No cherry-picking or post-hoc rule changes are permitted.

## Regression discrepancy procedure

Run S1+S4 first.

If any result differs from the historical result:
1. identify every mismatched variant;
2. compare old and new outputs;
3. independently verify each mismatched variant against the frozen gold label;
4. determine whether the refactor or historical result is incorrect;
5. fix the implementation or revise the historical claim accordingly.

Never modify the new implementation solely to reproduce a historical number.

## Determinism

Run the N=5 determinism screen separately.

Record all exclusions and reasons.
Non-zero exclusions are reported, not suppressed.

## Statistical reporting

For aggregate FAR and accuracy:
- report Wilson 95% confidence intervals.

Do not report confidence intervals for per-family or per-modification
subgroups (n <= 6).

## Evidence requirements

Each configuration must preserve:
- configuration name;
- protocol/version;
- input/variant identifiers;
- S1 evidence where applicable;
- T_R result where applicable;
- final decision;
- timestamp;
- code/provenance identifier.

## Interpretation

The ablation tests the intended division of labor between S1 and S4.

If the observed results show clean complementary coverage:
"The ablation confirms the intended division of labor between S1 and S4."

If coverage overlaps materially:
"S1 and S4 provide complementary but partially overlapping coverage."

The wording must follow the measured results.
