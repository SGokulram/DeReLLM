# DeReLLM Final Evidence Package

This package is intended as a research-evidence handoff.

The package contains:

- authoritative v6 benchmark evidence
- Phase 8 proposer evidence
- runtime evidence
- scope/status documentation
- superseded result artifacts preserved for auditability
- package file manifest and SHA-256 hashes

The authoritative benchmark result is explicitly identified in
`00_SCOPE/FINAL_EVIDENCE_STATUS.md`.
