# Superseded Result File

This directory preserves an older result artifact for auditability.

`VARIANT_RESULTS.csv` is NOT the authoritative source for the final
core benchmark claims.

The authoritative core benchmark is:

- `00_SCOPE/V6_RESULTS.csv`
- `00_SCOPE/v6_variants_manifest.json`
- `00_SCOPE/decision_log_v6.jsonl`

The older file disagrees with the authoritative v6 evidence on at least
the correct outcomes for `req4_correct` and `req6_correct`.

Therefore the superseded file must not be used when computing the final
paper metrics.
