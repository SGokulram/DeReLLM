# Known Result Discrepancy

Two result artifacts disagree on:

req4_correct
req6_correct

V6_RESULTS.csv reports ACCEPT.

paper_package/VARIANT_RESULTS.csv reports REJECT.

Do not silently merge these.
Resolve against underlying execution/verifier evidence.
